
const config = { backendEndpoint: "http://35.154.224.94:8082" };

export default config;
